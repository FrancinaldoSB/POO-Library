import threading
from queue import Queue

def criarLotes(self, start, end):
    for i in range(start, end, self.batch_size):
        batch_start = i
        batch_end = min(i + self.batch_size, end)
        self.task_queue.put((batch_start, batch_end))

def tranferirinfos(self, start, end):
    criarLotes(self, start, end)
    threads = []

    for _ in range(self.num_threads):
        thread = threading.Thread(target=self.worker)
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()